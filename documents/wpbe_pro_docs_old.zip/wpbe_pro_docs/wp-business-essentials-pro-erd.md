# WP Business Essentials Pro - Entity Relationship Diagram

## Overview
This ERD represents the complete data architecture for WP Business Essentials Pro, including the polymorphic message system, ticket management, lead conversion flow, and business entity relationships.

## Architecture Notes

### User Management Strategy
- **WordPress Core Users** (`wp_users` table) handles authentication
- **Roles**: administrator, editor, client, customer, free member, guest; Phase 2, team member
- **User Types**: Guest → Member → Client/Customer
- Custom tables and CPTs link to `wp_users.ID` via `user_id` fields

### Custom Tables (Private Data)
- `leads` - Qualified contacts (no WP account yet)
- `form_submissions` - Raw form data from public forms
- `messages` - Communication records
- `conversations` - Slack-style channels/threads
- `tickets` - Support system records

### Custom Post Types (Admin-Managed Content)
- `clients` - Service purchasers (links to wp_users)
- `projects` - Client projects
- `services` - Service offerings
- `invoices` - Billing records
- `appointments` - Scheduling
- `testimonials` - Client reviews
- `case_studies` - Archived project showcases
- `social_proof` - Social media mentions
- `faqs` - Frequently asked questions

---

## Entity Relationship Diagram

---
config:
  layout: elk
---
erDiagram
    %% ============================================
    %% WORDPRESS CORE (Reference Only)
    %% ============================================
    wp_users {
        bigint ID PK
        string user_login
        string user_email
        string user_role "administrator, editor, customer, subscriber"
        datetime user_registered
    }

    %% ============================================
    %% EXTERNAL REFERENCES (Not Created by Plugin)
    %% ============================================
    wc_products {
        bigint ID PK "WooCommerce product (wp_posts)"
        string post_title "Product name"
        decimal _regular_price "meta"
        decimal _sale_price "meta"
        string _sku "meta"
        string product_type "simple, variable, etc"
    }

    wc_orders {
        bigint ID PK "WooCommerce order (wp_posts)"
        string order_number
        decimal order_total
        string order_status "pending, completed, etc"
        bigint customer_id "wp_users.ID"
        datetime order_date
    }

    
    %% ============================================
    %% CUSTOM TABLES (Private/Secure)
    %% ============================================
    
    business_media {
        bigint id PK
        bigint attachment_id UK "WordPress attachment ID (wp_posts)"
        string storage_backend "wordpress, s3, do_spaces (future)"
        string file_url "Direct URL to file"
        string file_path "Server file path (optional)"
        string thumbnail_url "Thumbnail size URL"
        string medium_url "Medium size URL"
        string large_url "Large size URL"
        string file_name "Original filename"
        string file_type "image/jpeg, application/pdf, etc"
        string mime_type "MIME type"
        bigint file_size "File size in bytes"
        int width "Image/video width"
        int height "Image/video height"
        int duration "Video/audio duration in seconds"
        string alt_text "Alternative text"
        text caption "Media caption"
        text description "Media description"
        string entity_type "Polymorphic: service, project, message, etc"
        bigint entity_id "ID of related entity"
        string field_name "featured_image, gallery, attachment, etc"
        int display_order "For galleries/multiple media"
        bigint uploaded_by FK "wp_users.ID"
        text metadata "JSON: Full WordPress attachment metadata"
        text s3_bucket "Future: S3 bucket name"
        text s3_region "Future: S3 region"
        text s3_key "Future: S3 object key"
        datetime created_at
        datetime updated_at
    }

    wp_business_product_meta {
        bigint id PK
        bigint product_id FK "WooCommerce product ID (unique)"
        bigint related_service_id FK "Links to Services CPT"
        bigint related_team_member_id FK "Future: team member who provides service"
        text custom_fields "JSON: Additional custom fields"
        boolean is_service_product "True if creates project on purchase"
        boolean auto_create_project "True if should auto-create project"
        text project_template "JSON: Default project settings"
        datetime created_at
        datetime updated_at
    }

    analytics_events {
        bigint id PK
        string event_type "page_view, form_submit, product_viewed, order_created, etc"
        string entity_type "Polymorphic: product, lead, project, order, etc"
        bigint entity_id "ID of related entity"
        bigint user_id FK "wp_users.ID if authenticated"
        string session_id "Anonymous session identifier"
        string ip_address "User IP address"
        string user_agent "Browser user agent"
        string page_path "Current page path"
        string referrer "Referring page URL"
        text event_data "JSON: Additional event-specific data"
        datetime event_timestamp "When event occurred"
        datetime created_at
    }

    leads {
        bigint id PK
        string first_name
        string last_name
        string email UK
        string phone
        string company_name
        string source "contact_form, newsletter, quote_request, etc"
        string status "cold, warm, hot, converted, dead"
        decimal temperature "0-100 lead score"
        text notes
        datetime last_contact
        datetime created_at
        datetime updated_at
    }

    form_submissions {
        bigint id PK
        string form_type "contact_form, faq_question, newsletter_signup, quote_request, support_form"
        string sender_type "guest, member, client"
        bigint sender_id FK "NULL for guests, wp_users.ID for authenticated"
        string sender_email
        string sender_name
        string sender_phone
        text form_data "JSON serialized form fields"
        string ip_address
        string user_agent
        string status "pending, processed, converted, archived"
        bigint converted_to_id "ID of created lead/ticket/etc"
        string converted_to_type "lead, ticket, etc"
        datetime processed_at
        datetime created_at
    }

    conversations {
        bigint id PK
        string conversable_type "project, ticket, lead, client"
        bigint conversable_id FK "Polymorphic reference"
        string title "Optional conversation title"
        string status "active, archived, closed"
        datetime last_message_at
        datetime created_at
        datetime updated_at
    }

    messages {
        bigint id PK
        bigint conversation_id FK
        string sender_type "guest, member, client, admin"
        bigint sender_id FK "NULL for guests, wp_users.ID for authenticated"
        string sender_email "For guest identification"
        string sender_name "For guest messages"
        string subject
        text content
        string message_type "inquiry, response, internal_note, status_update"
        boolean is_read
        datetime read_at
        text metadata "JSON for attachments, email headers, etc"
        datetime created_at
        datetime updated_at
    }

    tickets {
        bigint id PK
        string ticket_number UK "Auto-generated: TICK-2025-0001"
        bigint user_id FK "wp_users.ID - Required (members/clients only)"
        bigint conversation_id FK "Links to conversation thread"
        string subject
        text description
        string priority "low, medium, high, urgent"
        string status "open, in_progress, waiting_response, resolved, closed"
        string category "technical, billing, general, feature_request"
        bigint assigned_to FK "wp_users.ID of team member"
        datetime claimed_at
        datetime resolved_at
        datetime closed_at
        datetime created_at
        datetime updated_at
    }

    %% ============================================
    %% CUSTOM POST TYPES (Business Entities)
    %% ============================================

    clients {
        bigint ID PK "wp_posts.ID"
        bigint user_id FK "wp_users.ID (unique - one client per user)"
        string company_name
        string contact_person
        string email
        string phone
        text billing_address
        string service_tier "bronze, silver, gold, platinum"
        decimal total_spent
        string status "active, inactive, on_hold"
        datetime first_purchase_date
        datetime last_purchase_date
        text notes
    }

    projects {
        bigint ID PK "wp_posts.ID"
        bigint client_id FK "clients.ID"
        bigint service_id FK "services.ID"
        bigint wc_order_id FK "WooCommerce order ID (if created from purchase)"
        string project_name
        text description
        string status "planning, in_progress, review, completed, archived"
        string priority "low, medium, high"
        decimal budget
        decimal actual_cost
        date start_date
        date deadline
        date completion_date
        boolean is_case_study "If true, can be featured as case study"
        text deliverables
        text requirements
        bigint conversation_id FK "Main project conversation"
    }

    services {
        bigint ID PK "wp_posts.ID"
        string service_name
        text description
        string service_type "web_development, mobile_app, consulting, seo, maintenance"
        decimal base_price
        string pricing_model "fixed, hourly, monthly, custom"
        text features "JSON array of features"
        boolean is_active
        int display_order
    }

    invoices {
        bigint ID PK "wp_posts.ID"
        string invoice_number UK "INV-2025-0001"
        bigint client_id FK "clients.ID"
        bigint project_id FK "projects.ID - NULL if not project-specific"
        decimal subtotal
        decimal tax_amount
        decimal total_amount
        string status "draft, sent, paid, overdue, cancelled"
        date issue_date
        date due_date
        date paid_date
        string payment_method "stripe, paypal, bank_transfer, check"
        text line_items "JSON array of invoice items"
        text notes
    }

    appointments {
        bigint ID PK "wp_posts.ID"
        bigint client_id FK "clients.ID - NULL for lead appointments"
        bigint lead_id FK "leads.id - NULL for client appointments"
        bigint project_id FK "projects.ID - NULL if general appointment"
        string appointment_type "free_consultation, project_consultation, technical_review, follow_up"
        datetime scheduled_datetime
        int duration_minutes
        string timezone
        string meeting_platform "zoom, google_meet, phone, in_person"
        text meeting_link
        text meeting_passcode
        text location_address
        text agenda
        text preparation_notes
        string status "scheduled, confirmed, completed, cancelled, no_show"
        boolean reminder_sent
        boolean confirmation_sent
        datetime created_at
        datetime updated_at
    }

    testimonials {
        bigint ID PK "wp_posts.ID"
        bigint client_id FK "clients.ID"
        bigint project_id FK "projects.ID - NULL if general testimonial"
        string reviewer_name
        text review_content
        int star_rating "1-5"
        string service_type
        boolean is_featured
        boolean is_approved
        date submitted_date
    }

    case_studies {
        bigint ID PK "wp_posts.ID"
        bigint project_id FK "projects.ID - Source project"
        bigint client_id FK "clients.ID"
        string project_title
        string client_name_display "May differ from actual client name"
        text problem_statement
        text solution_description
        text technologies_used
        text outcomes
        text metrics "JSON: traffic increase, conversions, etc"
        boolean is_featured
        date project_completion_date
    }

    social_proof {
        bigint ID PK "wp_posts.ID"
        string full_name
        string social_platform "twitter, instagram, facebook, tiktok, linkedin"
        string username
        string profile_link
        string share_link
        text screenshot_urls "JSON array of backup images"
        datetime share_date
        boolean is_featured
    }

    faqs {
        bigint ID PK "wp_posts.ID"
        string question
        text answer
        string category "general, technical, billing, services"
        int display_order
        int view_count
        boolean is_public
        datetime created_at
        datetime updated_at
    }

    dynamic_sections {
        bigint ID PK "wp_posts.ID"
        string section_type "hero, features_grid, testimonials_carousel, team_showcase, faq_accordion, product_grid, product_carousel"
        string section_title
        text section_description
        string layout_style "full_width, contained, split, asymmetric"
        string background_type "solid, gradient, image, video"
        text background_value "Color code, gradient CSS, media ID, etc"
        text content_data "JSON: Section-specific content configuration"
        int display_order "Order on page"
        boolean is_active
        string visibility "public, members_only, clients_only"
        text custom_css "Custom CSS for this section"
        text custom_js "Custom JavaScript for this section"
        datetime created_at
        datetime updated_at
    }

    dynamic_cards {
        bigint ID PK "wp_posts.ID"
        string card_type "feature_card, service_card, team_card, stat_card, cta_card, testimonial_card, product_card, pricing_card, general_card"
        string card_title
        text card_description
        string link_url "URL the card links to"
        string link_text "Button/link text"
        string layout_style "standard, compact, expanded, minimal"
        string background_type "solid, gradient, image, video"
        text background_value "Color code, gradient CSS, media ID, etc"
        text content_data "JSON: Card-specific content configuration"
        string linked_entity_type "Optional: service, project, testimonial, product, etc"
        bigint linked_entity_id "Optional: ID of related entity"
        int display_order "Ordering when used in collections"
        boolean is_active
        string visibility "public, members_only, clients_only"
        text custom_css "Custom CSS for this card"
        text custom_js "Custom JavaScript for this card"
        datetime created_at
        datetime updated_at
    }

    %% ============================================
    %% RELATIONSHIPS
    %% ============================================

    wp_users ||--o| clients : "has"
    wp_users ||--o{ tickets : "creates"
    wp_users ||--o{ tickets : "assigned_to"
    wp_users ||--o{ business_media : "uploads"
    business_media }o--|| wp_users : "uploaded_by"
    services ||--o{ business_media : "has_media"
    projects ||--o{ business_media : "has_media"
    clients ||--o{ business_media : "has_media"
    testimonials ||--o{ business_media : "has_media"
    case_studies ||--o{ business_media : "has_media"
    social_proof ||--o{ business_media : "has_media"
    messages ||--o{ business_media : "has_attachments"
    form_submissions ||--o{ business_media : "has_uploads"
    dynamic_sections ||--o{ business_media : "has_media"
    dynamic_cards ||--o{ business_media : "has_media"
    wc_products ||--o| wp_business_product_meta : "enhanced_by"
    wp_business_product_meta }o--o| services : "links_to_service"
    wp_business_product_meta }o--o| projects : "showcases_in_project"
    wp_business_product_meta }o--o| testimonials : "has_reviews"
    wc_orders ||--o| projects : "creates_project"
    wc_orders ||--o{ analytics_events : "tracked_by"
    wc_products ||--o{ analytics_events : "tracked_by"
    analytics_events }o--o| wp_users : "performed_by"
    analytics_events }o--o| leads : "relates_to"
    analytics_events }o--o| projects : "relates_to"
    analytics_events }o--o| clients : "relates_to"
    form_submissions ||--o| leads : "converts_to"
    leads ||--o{ appointments : "schedules"
    form_submissions ||--o| tickets : "creates"
    form_submissions }o--|| conversations : "may_create"
    conversations ||--o{ messages : "contains"
    projects ||--o| conversations : "has"
    tickets ||--|| conversations : "has"
    leads ||--o| conversations : "has"
    clients ||--o{ conversations : "has"
    messages }o--|| wp_users : "sent_by (if authenticated)"
    tickets ||--|| conversations : "belongs_to"
    tickets }o--|| wp_users : "created_by"
    tickets }o--o| wp_users : "assigned_to"
    clients ||--|| wp_users : "belongs_to"
    clients ||--o{ projects : "has"
    clients ||--o{ invoices : "has"
    clients ||--o{ appointments : "has"
    clients ||--o{ testimonials : "provides"
    clients ||--o{ case_studies : "featured_in"
    projects }o--|| clients : "belongs_to"
    projects }o--|| services : "based_on"
    projects ||--o{ invoices : "generates"
    projects ||--o{ appointments : "schedules"
    projects ||--o| case_studies : "becomes"
    projects ||--o| conversations : "has_channel"
    projects }o--o| testimonials : "receives"
    services ||--o{ projects : "used_in"
    invoices }o--|| clients : "billed_to"
    invoices }o--o| projects : "for"
    appointments }o--o| clients : "with_client"
    appointments }o--o| leads : "with_lead"
    appointments }o--o| projects : "regarding"
    testimonials }o--|| clients : "from"
    testimonials }o--o| projects : "about"
    case_studies }o--|| projects : "derived_from"
    case_studies }o--|| clients : "features"
    dynamic_cards }o--o| services : "links_to"
    dynamic_cards }o--o| projects : "links_to"
    dynamic_cards }o--o| testimonials : "links_to"
    dynamic_cards }o--o| clients : "links_to"
---

## Data Flow Diagrams

### 1. Lead Acquisition & Conversion Flow

```mermaid
flowchart TD
    A[Guest Visitor] -->|Fills Form| B[form_submissions]
    B -->|form_type: contact/newsletter/quote| C{Review Form}
    C -->|Qualify| D[Create Lead Record]
    D --> E[leads table]
    E -->|Nurture| F{Purchase Decision}
    F -->|Yes - Service Purchase| G[Create wp_users Account]
    G --> H[Create clients CPT]
    H --> I[Delete Lead Record]
    F -->|No| J[Update Lead Status]
    J -->|Continue Nurturing| E
```

### 2. Support Ticket Creation Flow

```mermaid
flowchart TD
    A[Client/Customer] -->|Logged In| B{Has Purchases?}
    B -->|Yes| C[Access Support Form]
    B -->|No| D[Redirect to Contact Form]
    C -->|Submit| E[form_submissions]
    E -->|form_type: support_form| F[Create ticket Record]
    F --> G[Create conversation]
    G --> H[Link ticket to conversation]
    H --> I[Email Admin Notification]
    I --> J[Admin Claims Ticket]
    J --> K[Communication via messages]
    K --> L{Issue Resolved?}
    L -->|Yes| M[Close Ticket]
    L -->|No| K
```

### 3. Message Communication Flow

```mermaid
flowchart TD
    A[User Action] --> B{User Type?}
    B -->|Guest| C[form_submissions]
    B -->|Member/Client| D[Direct Message]
    C --> E{Create Conversation?}
    E -->|Yes| F[Create conversation]
    E -->|No| G[Store as Form Submission]
    D --> H[Find/Create conversation]
    H --> I[Create message Record]
    F --> I
    I --> J{Notify Recipients}
    J -->|Email| K[Send Email Notification]
    J -->|In-App| L[Update Unread Count]
```

### 4. Project Lifecycle Flow

```mermaid
flowchart TD
    A[Client Created] --> B[Service Selected]
    B --> C[Create Project]
    C --> D[Create Project Conversation]
    D --> E[Project Planning Status]
    E --> F[Create Invoice]
    F --> G{Invoice Paid?}
    G -->|Yes| H[Project In Progress]
    G -->|No| I[Wait for Payment]
    I --> G
    H --> J[Client Communication via Messages]
    J --> K{Project Complete?}
    K -->|Yes| L[Project Completed Status]
    K -->|No| H
    L --> M{Create Case Study?}
    M -->|Yes| N[Archive as case_study]
    M -->|No| O[Project Archived]
```

### 5. WooCommerce Purchase Flow (Service Products)

```mermaid
flowchart TD
    A[Customer Browses Products] --> B{Product has related_service_id?}
    B -->|No| C[Regular Product Purchase]
    B -->|Yes| D[Service-Based Product]
    C --> E[WooCommerce Order Created]
    D --> E
    E --> F[Track: purchase_completed event]
    F --> G{Is Service Product?}
    G -->|No| H[Order Complete]
    G -->|Yes| I[Check: auto_create_project?]
    I -->|Yes| J[Create Client Record if needed]
    J --> K[Create Project Record]
    K --> L[Link Project to Order wc_order_id]
    L --> M[Create Project Conversation]
    M --> N[Notify Team]
    N --> O[Client Onboarding]
```

### 6. Media Upload & Association Flow

```mermaid
flowchart TD
    A[File Upload Triggered] --> B{Upload Source?}
    B -->|Form Submission| C[Process Form Upload]
    B -->|Direct Upload| D[Process Direct Upload]
    B -->|Admin Upload| E[Process Admin Upload]
    
    C --> F[Upload to WordPress Media Library]
    D --> F
    E --> F
    
    F --> G[Get attachment_id]
    G --> H[Create business_media Record]
    
    H --> I{Entity Association?}
    I -->|Form| J[Link to form_submissions]
    I -->|Message| K[Link to messages as attachment]
    I -->|Project| L[Link to projects as gallery]
    I -->|Service| M[Link to services as featured_image]
    I -->|Client| N[Link to clients as logo]
    
    J --> O[Store entity_type & entity_id]
    K --> O
    L --> O
    M --> O
    N --> O
    
    O --> P[Generate URLs: thumbnail, medium, large]
    P --> Q[Store metadata JSON]
    Q --> R[Upload Complete]
```

---

## Key Design Patterns

### Media Management System

#### Universal Media Wrapper
The `business_media` table provides a unified interface for all file uploads across the plugin:

**Core Concept**: Every uploaded file gets a wrapper record that:
1. References WordPress media library (`attachment_id`)
2. Provides 3 access methods (ID, URL, Metadata)
3. Can attach to ANY entity via polymorphic relationship
4. Supports future storage backends (S3, DigitalOcean Spaces)

**Access Methods**:
```php
// Method 1: By attachment ID
$media = get_business_media(['attachment_id' => 789]);

// Method 2: By URL
$media = get_business_media(['file_url' => 'https://...']);

// Method 3: By entity association
$media = get_business_media([
  'entity_type' => 'project',
  'entity_id' => 123,
  'field_name' => 'gallery'
]);

// Returns consistent structure:
[
  'id' => 456,
  'attachment_id' => 789,
  'file_url' => 'https://...',
  'thumbnail_url' => 'https://...',
  'metadata' => {...}, // Full WordPress attachment object
  'entity_type' => 'project',
  'entity_id' => 123
]
```

**Field Types Supporting Media**:
- `featured_image` - Single image (services, projects, clients)
- `gallery` - Multiple images (projects, case studies)
- `attachment` - Files (messages, form submissions)
- `logo` - Brand assets (clients)
- `profile_photo` - User images (testimonials)

**Storage Backend Flexibility**:
```sql
-- Phase 1: WordPress (current)
storage_backend = 'wordpress'
file_url = 'https://site.com/wp-content/uploads/2025/01/file.jpg'

-- Phase 2: AWS S3 (future)
storage_backend = 's3'
file_url = 'https://bucket.s3.amazonaws.com/file.jpg'
s3_bucket = 'my-bucket'
s3_region = 'us-east-1'
s3_key = 'uploads/2025/01/file.jpg'

-- Phase 3: DigitalOcean Spaces (future)
storage_backend = 'do_spaces'
file_url = 'https://space.nyc3.digitaloceanspaces.com/file.jpg'
```

**File Upload Processing**:
1. User uploads file (form, direct upload, admin)
2. File stored in WordPress media library → `attachment_id`
3. Create `business_media` record with polymorphic association
4. Generate multiple size URLs (thumbnail, medium, large)
5. Store full metadata JSON for easy access
6. Return consistent media object to frontend

---

### WooCommerce Integration

#### Conditional Feature Activation
WooCommerce features only activate when WooCommerce plugin is installed:

```php
if (class_exists('WooCommerce')) {
  // Enable e-commerce features
  - Product enhancements table
  - Product analytics tracking
  - Auto-project creation
  - Enhanced REST endpoints
}
```

#### Invoice Enhancement Architecture

**Invoice Payment Processing**:
Invoices support multiple payment gateways while staying independent from WooCommerce:

```sql
invoices:
  - payment_method (stripe, paypal, bank_transfer, check)
  - payment_gateway (jetformbuilder, stripe_direct, manual)
  - stripe_charge_id (Stripe payment ID)
  - paypal_transaction_id (PayPal transaction ID)
```

**Payment Flow**:
```
1. Admin creates invoice CPT (project work, $5000)
2. Invoice generates "Pay Invoice #123" link
3. Send link to client
4. Link goes to JetFormBuilder checkout page
5. Client pays via Stripe/PayPal
6. Payment webhook → update invoice status
7. Store payment gateway ID (stripe_charge_id or paypal_transaction_id)
```

**Key Design Decision**:
- Invoices do NOT create WooCommerce orders
- Systems remain separate for simplicity
- JetFormBuilder handles payment processing
- Invoice tracks payment source via gateway fields

---

#### Product Enhancement Architecture
WooCommerce handles products; you enhance them with relationships:

**What WooCommerce Provides**:
- Product CPT (manages product data, inventory, pricing)
- Order system (checkout, payments, shipping)
- Customer management
- REST API endpoints

**What You Add** (`wp_business_product_meta`):
- Link products to Services CPT
- Link products to Team Members (future)
- Auto-create projects on purchase
- Product analytics events
- Custom product fields

**Example Flow**:
```
Customer purchases "Website Design Package" (WooCommerce product)
  ↓
wp_business_product_meta lookup:
  - related_service_id: 456 (Web Development service)
  - auto_create_project: true
  ↓
System automatically:
  1. Creates Client record (if first purchase)
  2. Creates Project record linked to Service
  3. Links Project to WooCommerce Order (wc_order_id)
  4. Creates Project Conversation
  5. Notifies team
  6. Tracks analytics event: 'purchase_completed'
```

#### Product Analytics Events
Track e-commerce behavior in unified `analytics_events` table:

```sql
-- Product viewed
INSERT INTO analytics_events (
  event_type, entity_type, entity_id, user_id, event_data
) VALUES (
  'product_viewed',
  'product',
  123,
  NULL,
  '{"product_name":"Website Design","price":1500}'
);

-- Add to cart
event_type: 'add_to_cart'
entity_type: 'product'

-- Cart abandoned
event_type: 'cart_abandoned'
entity_type: 'cart'

-- Purchase completed
event_type: 'purchase_completed'
entity_type: 'order'
entity_id: [WooCommerce order ID]
```

#### Enhanced Product Endpoints
note: the route name "enhanced" is a tentative param name. I am open to changes here.
Your custom endpoints extend WooCommerce data:

```
GET /wp-json/wpbe/v1/products/enhanced/{id}
Returns: WooCommerce product + your enhancements
{
  "id": 123,
  "name": "Website Design Package",
  "price": 1500,
  "related_service": {...}, // Your Services CPT data
  "team_member": {...},     // Future: team member info
  "sample_projects": [...], // Projects using this product
  "testimonials": [...]     // Reviews for this product
}
```

---

### Dynamic Sections System

#### Section-Based Page Builder
Dynamic Sections provide flexible content management for frontend pages:

**Section Types**:

**Content Sections**:
- `hero` - Hero banner with CTA
- `features_grid` - Feature cards in grid layout
- `testimonials_carousel` - Rotating testimonials
- `team_showcase` - Team member cards
- `faq_accordion` - Expandable FAQ list

**E-Commerce Sections** (if WooCommerce active):
- `product_grid` - Product cards in grid
- `product_carousel` - Rotating products
- `featured_products` - Highlighted products
- `product_categories` - Category showcase

**Section Configuration**:
```json
// Stored in content_data field
{
  "section_type": "product_grid",
  "items_per_row": 3,
  "show_price": true,
  "show_add_to_cart": true,
  "filter_by_category": ["web-design", "seo"],
  "display_order": "price_asc"
}
```

**Section Rendering**:
```php
// Query sections for a page
$sections = get_dynamic_sections([
  'visibility' => 'public',
  'is_active' => true,
  'orderby' => 'display_order'
]);

foreach ($sections as $section) {
  render_section($section->section_type, $section->content_data);
}
```

---

### Dynamic Cards System

#### Independent Card Components
Dynamic Cards are reusable, standalone content components similar to Dynamic Sections but designed for smaller, modular content blocks.

**Core Concept**: Each card is an independent entity that can be:
1. Rendered via shortcode: `[dynamic_card id="123"]`
2. Inserted as a block in page builders
3. Fetched via REST API and rendered in frontend
4. Optionally linked to other CPTs (services, projects, testimonials)

**Card Types**:

**Content Cards**:
- `feature_card` - Service/product feature highlights
- `service_card` - Service offering cards
- `stat_card` - Statistics/metrics display
- `cta_card` - Call-to-action cards
- `testimonial_card` - Customer review cards
- `team_card` - Team member profile cards (future)
- `general_card` - Generic content cards

**E-Commerce Cards** (if WooCommerce active):
- `product_card` - Individual product displays
- `pricing_card` - Pricing tier cards

**Fixed Fields Structure**:
```sql
dynamic_cards:
  - card_title (main heading)
  - card_description (body text)
  - link_url (where card links to)
  - link_text (button/link label)
  - layout_style (standard, compact, expanded, minimal)
  - background_type (solid, gradient, image, video)
  - background_value (styling data)
  - content_data (JSON: card-specific extras)
  - custom_css (card-specific styling)
  - custom_js (card-specific scripts)
```

**Polymorphic Entity Linking**:
Cards can optionally link to other CPTs to pull live data:

```php
// Feature card linked to Service
$card = get_dynamic_card(123);
if ($card->linked_entity_type === 'service') {
  $service = get_post($card->linked_entity_id);
  // Use service data in card rendering
}

// Testimonial card linked to Testimonial CPT
if ($card->linked_entity_type === 'testimonial') {
  $testimonial = get_post($card->linked_entity_id);
  // Display actual testimonial data
}
```

**Content Data Examples**:
```json
// Feature Card
{
  "icon_style": "outlined",
  "hover_effect": "lift",
  "animation": "fade-in"
}

// Stat Card
{
  "number_prefix": "$",
  "number_suffix": "M",
  "counter_animation": true,
  "counter_duration": 2000
}

// CTA Card
{
  "button_style": "primary",
  "button_size": "large",
  "alignment": "center"
}
```

**Media Integration**:
Cards use single featured image from `business_media`:

```sql
business_media:
  entity_type: 'dynamic_card'
  entity_id: 123
  field_name: 'featured_image'
```

Common use cases:
- Icon for feature cards
- Photo for team cards
- Background image for hero cards
- Product image for product cards

**Rendering Examples**:

```php
// Via Shortcode
[dynamic_card id="123"]
[dynamic_card id="456" style="compact"]

// Via API
GET /wp-json/wpbe/v1/cards/123
Returns: Complete card object with media and linked entity data

// Programmatically
$card = get_dynamic_card(123);
if ($card->is_active && check_card_visibility($card)) {
  render_card($card);
}
```

**Usage Patterns**:

1. **Feature Showcases**: Create 6 feature cards, render in grid
2. **Service Offerings**: Cards linked to Services CPT, auto-update pricing
3. **Team Profiles**: Cards for each team member with photo and bio
4. **Statistics**: Animated counter cards for key metrics
5. **Testimonials**: Cards linked to Testimonials CPT for social proof
6. **CTAs**: Reusable call-to-action cards throughout site

---

### Guest Users & Anonymous Tracking

#### Lightweight Guest Identification
The `guest_users` table provides a lightweight system for tracking anonymous visitors before they become leads or members.

**Core Concept**: Each anonymous visitor gets a unique `guest_id` that:
1. Tracks their journey across the site
2. Links all their analytics events together
3. Stores marketing attribution (UTM parameters)
4. Converts to lead/member when they identify themselves
5. Enables guest → lead → client conversion tracking

**Guest User Structure**:
```sql
guest_users:
  - guest_id (UUID unique identifier)
  - session_token (authentication token)
  - first_seen, last_seen (timestamps)
  - utm_source, utm_medium, utm_campaign (marketing attribution)
  - page_views_count, events_count (activity counters)
  - converted_to_lead_id (links to leads table)
  - converted_to_user_id (links to wp_users)
  - status (active, converted, expired)
  - session_data (JSON - optional state storage)
```

**Integration with Analytics Events**:
```sql
-- Guest visits site
INSERT INTO guest_users (guest_id, utm_source, referrer_url);

-- Track anonymous events
INSERT INTO analytics_events (event_type, guest_id, page_path);

-- Guest fills out form (becomes lead)
UPDATE guest_users SET converted_to_lead_id = 123, status = 'converted';

-- Now query complete journey
SELECT * FROM analytics_events WHERE guest_id = 'uuid-123';
-- Returns: All page views, clicks, form interactions before conversion
```

**Conversion Flow**:
```
Guest (anonymous) → analytics_events track behavior
  ↓ (fills form with email)
Lead (identified) → guest_users.converted_to_lead_id set
  ↓ (creates account OR)
Member (wp_user) → guest_users.converted_to_user_id set
  ↓ (purchases service OR)
Client (client CPT) → complete conversion tracking
```

**Session Data Usage** (Optional):
The `session_data` JSON field can store temporary state:
```json
{
  "cart": [{"product_id": 456, "quantity": 1}],
  "form_progress": {
    "contact_form": {"step": 2, "fields": {...}}
  },
  "preferences": {
    "currency": "USD",
    "language": "en"
  }
}
```

**When to use `session_data`:**
- Cart persistence for guests
- Multi-step form progress
- Abandoned cart/form recovery
- Cross-device session continuation

**When NOT to use `session_data`:**
- Simple page view tracking (use analytics_events)
- One-time events (use analytics_events)
- Client-side only state (use localStorage)

**Data Retention & Cleanup**:
```sql
-- Configurable via wp_options
WPBE_Settings::set('guest_cleanup_days', 90);
WPBE_Settings::set('converted_guest_retention_days', 365);

-- Automated cleanup (WordPress cron)
DELETE FROM guest_users 
WHERE status = 'active' 
  AND last_seen < DATE_SUB(NOW(), INTERVAL 90 DAY);
```

**Benefits**:
- ✅ Complete visitor journey tracking
- ✅ Marketing attribution (UTM tracking)
- ✅ Lead source identification
- ✅ Conversion funnel analysis
- ✅ Lightweight (no heavy session data unless needed)
- ✅ GDPR-friendly (configurable retention, easy deletion)

---

### Polymorphic Relationships

#### Conversations (Polymorphic Owner)
A conversation can belong to multiple entity types:

```sql
-- Conversation for a Project
conversable_type = 'project'
conversable_id = 123 (projects.ID)

-- Conversation for a Ticket
conversable_type = 'ticket'
conversable_id = 456 (tickets.id)

-- Conversation for a Lead
conversable_type = 'lead'
conversable_id = 789 (leads.id)

-- Conversation for a Client (general communication)
conversable_type = 'client'
conversable_id = 101 (clients.ID)
```

#### Messages (Polymorphic Sender)
Messages can be sent by different user types:

```sql
-- Guest Message
sender_type = 'guest'
sender_id = NULL
sender_email = 'guest@example.com'
sender_name = 'John Doe'

-- Member Message
sender_type = 'member'
sender_id = 42 (wp_users.ID)
sender_email = NULL (retrieved from wp_users)

-- Client Message
sender_type = 'client'
sender_id = 42 (wp_users.ID)
sender_email = NULL (retrieved from wp_users)

-- Admin Message
sender_type = 'admin'
sender_id = 1 (wp_users.ID)
sender_email = NULL (retrieved from wp_users)
```

### User Type Progression

```
Guest (no account)
  ↓ (form submission)
Lead (custom table, no wp account)
  ↓ (free registration OR)
Member (wp_users, role: customer)
  ↓ (purchase service)
Client (wp_users + clients CPT)
```

### Ticket System Rules

1. **Creation**: Only authenticated users (Members/Clients/Customers)
2. **Validation**: Check `is_user_logged_in()` && `user_has_purchases()`
3. **Conversation**: Every ticket has one conversation
4. **Messages**: All ticket communication flows through messages table
5. **Status Tracking**: Open → In Progress → Resolved → Closed

---

## Database Indexing Strategy

### Critical Indexes for Performance

```sql
-- Leads
CREATE INDEX idx_leads_email ON leads(email);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_created ON leads(created_at);

-- Form Submissions
CREATE INDEX idx_form_type ON form_submissions(form_type);
CREATE INDEX idx_form_status ON form_submissions(status);
CREATE INDEX idx_form_sender ON form_submissions(sender_type, sender_id);

-- Conversations
CREATE INDEX idx_conversable ON conversations(conversable_type, conversable_id);
CREATE INDEX idx_conversation_status ON conversations(status);

-- Messages
CREATE INDEX idx_message_conversation ON messages(conversation_id);
CREATE INDEX idx_message_sender ON messages(sender_type, sender_id);
CREATE INDEX idx_message_created ON messages(created_at);
CREATE INDEX idx_message_unread ON messages(is_read);

-- Tickets
CREATE INDEX idx_ticket_user ON tickets(user_id);
CREATE INDEX idx_ticket_status ON tickets(status);
CREATE INDEX idx_ticket_assigned ON tickets(assigned_to);
CREATE INDEX idx_ticket_created ON tickets(created_at);

-- Clients
CREATE INDEX idx_client_user ON clients(user_id);
CREATE INDEX idx_client_status ON clients(status);

-- Guest Users
CREATE INDEX idx_guest_id ON guest_users(guest_id);
CREATE INDEX idx_guest_status ON guest_users(status);
CREATE INDEX idx_guest_last_seen ON guest_users(last_seen);
CREATE INDEX idx_guest_converted_lead ON guest_users(converted_to_lead_id);
CREATE INDEX idx_guest_converted_user ON guest_users(converted_to_user_id);
CREATE INDEX idx_guest_utm_source ON guest_users(utm_source);

-- Business Media
CREATE INDEX idx_media_attachment ON business_media(attachment_id);
CREATE INDEX idx_media_entity ON business_media(entity_type, entity_id);
CREATE INDEX idx_media_field ON business_media(field_name);
CREATE INDEX idx_media_backend ON business_media(storage_backend);
CREATE INDEX idx_media_uploaded ON business_media(uploaded_by);
CREATE INDEX idx_media_created ON business_media(created_at);

-- Product Meta
CREATE INDEX idx_product_meta_product ON wp_business_product_meta(product_id);
CREATE INDEX idx_product_meta_service ON wp_business_product_meta(related_service_id);
CREATE INDEX idx_product_meta_team ON wp_business_product_meta(related_team_member_id);

-- Analytics Events
CREATE INDEX idx_analytics_event_type ON analytics_events(event_type);
CREATE INDEX idx_analytics_entity ON analytics_events(entity_type, entity_id);
CREATE INDEX idx_analytics_user ON analytics_events(user_id);
CREATE INDEX idx_analytics_session ON analytics_events(session_id);
CREATE INDEX idx_analytics_timestamp ON analytics_events(event_timestamp);
```

---

## Security Considerations

### Data Access Control

1. **Custom Tables** (leads, messages, tickets, conversations, form_submissions)
   - Not exposed via WordPress REST API
   - Require custom endpoints with authentication
   - Role-based access control

2. **Custom Post Types** (clients, projects, invoices, etc.)
   - Use `capability_type` and `capabilities` in CPT registration
   - Admin-only access by default
   - Custom REST API endpoints with permission callbacks

3. **Message Privacy**
   - Internal notes: Admin only
   - Client messages: Client + assigned team member + admin
   - Ticket messages: Ticket creator + assigned team member + admin
   - Guest messages: Admin only (no direct client access)

### WordPress Capabilities

```php
// Custom capabilities for message system
'read_private_messages'
'edit_private_messages'
'claim_tickets'
'assign_tickets'
'manage_leads'
'convert_leads'
'view_client_data'
```

---

## API Endpoints (Planned)

### Custom REST API Routes

```
# Form Submissions
POST   /wp-json/wpbe/v1/forms/submit
POST   /wp-json/wpbe/v1/forms/submit-with-files

# Leads Management
POST   /wp-json/wpbe/v1/leads/create
GET    /wp-json/wpbe/v1/leads
GET    /wp-json/wpbe/v1/leads/{id}
PUT    /wp-json/wpbe/v1/leads/{id}
PUT    /wp-json/wpbe/v1/leads/{id}/convert
DELETE /wp-json/wpbe/v1/leads/{id}

# Conversations & Messages
GET    /wp-json/wpbe/v1/conversations
GET    /wp-json/wpbe/v1/conversations/{id}
GET    /wp-json/wpbe/v1/conversations/{id}/messages
POST   /wp-json/wpbe/v1/conversations/{id}/messages
POST   /wp-json/wpbe/v1/conversations/create

# Support Tickets
POST   /wp-json/wpbe/v1/tickets/create
GET    /wp-json/wpbe/v1/tickets
GET    /wp-json/wpbe/v1/tickets/{id}
PUT    /wp-json/wpbe/v1/tickets/{id}/claim
PUT    /wp-json/wpbe/v1/tickets/{id}/update-status
PUT    /wp-json/wpbe/v1/tickets/{id}/resolve
PUT    /wp-json/wpbe/v1/tickets/{id}/close

# Media Management
POST   /wp-json/wpbe/v1/media/upload
POST   /wp-json/wpbe/v1/media/upload-multiple
POST   /wp-json/wpbe/v1/media/associate
GET    /wp-json/wpbe/v1/media/{id}
GET    /wp-json/wpbe/v1/media/by-entity/{entity_type}/{entity_id}
GET    /wp-json/wpbe/v1/media/by-field/{entity_type}/{entity_id}/{field_name}
DELETE /wp-json/wpbe/v1/media/{id}

# WooCommerce Extensions
GET    /wp-json/wpbe/v1/products/enhanced/{id}
GET    /wp-json/wpbe/v1/products/with-service/{service_id}
GET    /wp-json/wpbe/v1/products/featured
POST   /wp-json/wpbe/v1/products/track-view
POST   /wp-json/wpbe/v1/products/track-cart

# Analytics
GET    /wp-json/wpbe/v1/analytics/events
GET    /wp-json/wpbe/v1/analytics/products
GET    /wp-json/wpbe/v1/analytics/conversions
POST   /wp-json/wpbe/v1/analytics/track

# Guest Tracking
POST   /wp-json/wpbe/v1/guests/create
GET    /wp-json/wpbe/v1/guests/{guest_id}
PUT    /wp-json/wpbe/v1/guests/{guest_id}/convert-to-lead
GET    /wp-json/wpbe/v1/guests/{guest_id}/journey

# Clients & Projects
GET    /wp-json/wpbe/v1/clients/{id}/projects
GET    /wp-json/wpbe/v1/clients/{id}/invoices
GET    /wp-json/wpbe/v1/clients/{id}/conversations
GET    /wp-json/wpbe/v1/clients/{id}/media

# Dynamic Sections
GET    /wp-json/wpbe/v1/sections
GET    /wp-json/wpbe/v1/sections/{id}
GET    /wp-json/wpbe/v1/sections/by-type/{section_type}
POST   /wp-json/wpbe/v1/sections/render

# Dynamic Cards
GET    /wp-json/wpbe/v1/cards
GET    /wp-json/wpbe/v1/cards/{id}
GET    /wp-json/wpbe/v1/cards/by-type/{card_type}
POST   /wp-json/wpbe/v1/cards/render
GET    /wp-json/wpbe/v1/cards/by-entity/{entity_type}/{entity_id}
```

---

## Phase Implementation Strategy

### Phase 1: Foundation ✅
**Core Business Entities**
- ✅ Clients CPT
- ✅ Projects CPT
- ✅ Services CPT
- ✅ Invoices CPT
- ✅ Appointments CPT
- ✅ Testimonials CPT
- ✅ Case Studies CPT
- ✅ Social Proof CPT
- ✅ FAQs CPT
- ✅ Dynamic Sections CPT
- ✅ Leads custom table
- ✅ Form submissions custom table

**Media Management System** 🆕
- ✅ business_media custom table
- ✅ WordPress media library integration
- ✅ Polymorphic entity associations
- ✅ Single & multiple file uploads
- ✅ Form file upload support
- ⏳ S3/cloud storage (Phase 3)

**WooCommerce Integration** (Conditional) 🆕
- ✅ wp_business_product_meta table
- ✅ Product-service linking
- ✅ Auto-project creation on purchase
- ✅ E-commerce analytics events
- ✅ Enhanced product endpoints

### Phase 2: Communication System 🔄
**Message & Conversation System**
- 🔄 Messages custom table
- 🔄 Conversations custom table
- 🔄 Polymorphic relationships
- 🔄 Email integration
- 🔄 Message attachments (uses business_media)

**Support System**
- 🔄 Tickets custom table
- 🔄 Ticket claiming/assignment
- 🔄 Ticket status workflow
- 🔄 Support form validation

**Analytics & Events**
- ✅ analytics_events custom table (unified)
- 🔄 Dashboard visualization
- 🔄 Real-time event tracking
- 🔄 Conversion funnel analysis

### Phase 3: Advanced Features ⏳
**Team Management**
- ⏳ Team Members CPT
- ⏳ Role-based permissions
- ⏳ Team member assignment
- ⏳ Team analytics

**Cloud Storage**
- ⏳ AWS S3 integration
- ⏳ DigitalOcean Spaces integration
- ⏳ Storage backend switching
- ⏳ CDN integration

**Email Marketing**
- ⏳ Email campaign system
- ⏳ Template management
- ⏳ Subscriber management
- ⏳ Automated workflows

**Advanced Automation**
- ⏳ Workflow builder
- ⏳ Trigger-action system
- ⏳ Integration webhooks
- ⏳ Zapier/Make integration

---

## Notes for Development

### WordPress Integration Points

1. **User Registration Hooks**
   - `user_register` - Create client CPT on service purchase
   - `woocommerce_order_status_completed` - Convert lead to customer

2. **Form Processing**
   - Use `wp_remote_post()` for external API integration
   - Store raw form data before processing
   - Implement spam protection (reCAPTCHA, honeypot)

3. **Email Notifications**
   - Use `wp_mail()` with custom templates
   - Queue emails for large broadcasts
   - Track email opens/clicks (optional)

### Performance Optimization

1. **Caching Strategy**
   - Object cache for frequently accessed data
   - Transients for expensive queries
   - Fragment caching for dynamic content

2. **Database Optimization**
   - Regular cleanup of processed form submissions
   - Archive old conversations (>1 year)
   - Implement soft deletes for audit trail

3. **Query Optimization**
   - Use `WP_Query` with pagination
   - Limit JOIN complexity
   - Eager load relationships when possible

---

## Conclusion

This ERD provides the complete data architecture for WP Business Essentials Pro, featuring:

### Core Systems
- ✅ **Polymorphic message system** (attach to any resource)
- ✅ **Slack-style conversation channels** (organized communication)
- ✅ **Support ticket management** (help desk system)
- ✅ **Lead acquisition and conversion flow** (guest → lead → client)
- ✅ **WordPress user integration** (no separate user management)
- ✅ **Flexible form submission handling** (multiple form types)

### New Features (Phase 1)
- ✅ **Media management system** (universal file wrapper with polymorphic associations)
- ✅ **WooCommerce integration** (conditional, extends products with business relationships)
- ✅ **Dynamic sections** (flexible content management for frontend)
- ✅ **Unified analytics** (track all events: user behavior, e-commerce, system events)

### Technical Architecture
- ✅ **Privacy and security by design** (custom tables for sensitive data)
- ✅ **Scalable for future features** (polymorphic relationships, modular design)
- ✅ **External service integration** (WooCommerce, future cloud storage)
- ✅ **Performance optimized** (proper indexing, caching strategy)

### Future-Proof Design
- ✅ **Storage backend abstraction** (easy switch to S3/Spaces later)
- ✅ **Conditional features** (WooCommerce only loads if installed)
- ✅ **Extensible entity system** (all CPTs support media, conversations, analytics)
- ✅ **Phase-based implementation** (clear upgrade path)

The design balances WordPress conventions with custom functionality, ensuring the plugin is maintainable, secure, and extensible for all current and future business needs.

### Entity Summary

**Custom Tables (9):**
1. business_media
2. wp_business_product_meta
3. analytics_events
4. guest_users
5. leads
6. form_submissions
7. conversations
8. messages
9. tickets

**Custom Post Types (11):**
1. clients
2. projects
3. services
4. invoices
5. appointments
6. testimonials
7. case_studies
8. social_proof
9. faqs
10. dynamic_sections
11. dynamic_cards

**External References (2):**
1. WooCommerce products
2. WooCommerce orders

**Total Entities: 22** (9 custom tables + 11 CPTs + 2 external references)

